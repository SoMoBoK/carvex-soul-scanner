# CARV Soul Scanner 🔮 (Ultra Simple HTML + JS)

Runs in browser • Connects Backpack Wallet • Shows Soul Score + Traits + AI Insight

## How to use
1. Open `index.html` in browser
2. Connect Backpack wallet
3. Enter optional CARV UID
4. Click "Scan Soul"

## Deploy to Vercel
- Upload files to GitHub
- Import to Vercel
- Done ✅
